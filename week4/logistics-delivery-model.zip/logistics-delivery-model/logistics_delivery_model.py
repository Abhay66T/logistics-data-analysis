"""
Predictive Modeling and Optimization in Logistics Systems
Forecasts delivery time (hours) and optimizes vehicle assignment.
Run: python logistics_delivery_model.py
"""
import numpy as np
import pandas as pd
from scipy.optimize import linprog
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import KFold, RandomizedSearchCV, cross_val_score, train_test_split
from sklearn.tree import DecisionTreeRegressor

SEED = 42
SLA_HOURS = 12
RUSH_HOURS = [7, 8, 9, 17, 18, 19]


def simulate_data(n=5000, seed=SEED):
    rng = np.random.default_rng(seed)
    df = pd.DataFrame({
        "distance_km": rng.gamma(4, 60, n).clip(10, 1500),
        "package_weight_kg": rng.lognormal(2, 0.8, n).clip(0.5, 200),
        "num_stops": rng.integers(1, 15, n),
        "traffic_index": rng.uniform(1, 10, n),
        "weather_severity": rng.choice([0, 1, 2, 3], n, p=[.55, .25, .15, .05]),
        "hour_of_day": rng.integers(0, 24, n),
        "is_weekend": rng.integers(0, 2, n),
        "vehicle_type": rng.choice(["van", "truck", "bike"], n, p=[.5, .35, .15]),
        "warehouse_load_pct": rng.uniform(30, 100, n),
    })
    speed = df.vehicle_type.map({"van": 55, "truck": 45, "bike": 20})
    rush = df.hour_of_day.isin(RUSH_HOURS).astype(int)
    df["delivery_time_hr"] = (
        df.distance_km / speed * (1 + 0.06 * df.traffic_index + 0.25 * rush)
        + 0.15 * df.num_stops + 0.004 * df.package_weight_kg
        + 0.35 * df.weather_severity
        + 0.012 * np.maximum(df.warehouse_load_pct - 80, 0) ** 1.3 / 3
        - 0.2 * df.is_weekend + rng.normal(0, 0.5, n)
    ).clip(0.3)
    df.loc[rng.choice(n, 100, replace=False), "traffic_index"] = np.nan
    return df


def prepare(df):
    df = df.copy()
    df["traffic_index"] = df.traffic_index.fillna(df.traffic_index.median())
    df["is_rush_hour"] = df.hour_of_day.isin(RUSH_HOURS).astype(int)
    df["dist_x_traffic"] = df.distance_km * df.traffic_index
    X = pd.get_dummies(df.drop(columns="delivery_time_hr"),
                       columns=["vehicle_type"], drop_first=True)
    return X, df.delivery_time_hr


def compare_models(X_train, y_train, X_test, y_test, kf):
    models = {
        "Linear Regression": LinearRegression(),
        "Decision Tree": DecisionTreeRegressor(max_depth=8, random_state=SEED),
        "Random Forest": RandomForestRegressor(n_estimators=200, random_state=SEED, n_jobs=-1),
        "Gradient Boosting": GradientBoostingRegressor(random_state=SEED),
    }
    for name, m in models.items():
        cv = -cross_val_score(m, X_train, y_train, cv=kf, scoring="neg_root_mean_squared_error")
        m.fit(X_train, y_train)
        p = m.predict(X_test)
        print(f"{name:18s} CV RMSE {cv.mean():.3f}+/-{cv.std():.3f} | "
              f"Test RMSE {mean_squared_error(y_test, p) ** .5:.3f} "
              f"MAE {mean_absolute_error(y_test, p):.3f} R2 {r2_score(y_test, p):.3f}")


def tune(X_train, y_train, kf):
    params = {"n_estimators": [100, 200, 300, 500], "learning_rate": [0.03, 0.05, 0.1],
              "max_depth": [2, 3, 4, 5], "subsample": [0.7, 0.85, 1.0],
              "min_samples_leaf": [1, 5, 10]}
    s = RandomizedSearchCV(GradientBoostingRegressor(random_state=SEED), params, n_iter=15,
                           cv=kf, scoring="neg_root_mean_squared_error",
                           random_state=SEED, n_jobs=-1).fit(X_train, y_train)
    print("Best params:", s.best_params_)
    return s.best_estimator_


def sla_alert(y_test, pred):
    late = y_test.values > SLA_HOURS
    flag = pred > 0.9 * SLA_HOURS
    print(f"SLA breach rate {late.mean():.3f} | recall {(flag & late).sum() / late.sum():.3f} "
          f"| precision {(flag & late).sum() / flag.sum():.3f}")


def optimize_assignment(model, routes, n=60):
    rate = {"van": 0.9, "truck": 1.5, "bike": 0.4}
    cols = []
    for v in ["van", "truck", "bike"]:
        r = routes.copy()
        r["vehicle_type_truck"] = int(v == "truck")
        r["vehicle_type_van"] = int(v == "van")
        t = model.predict(r)
        cols.append(t * rate[v] * 10 + 40 * np.maximum(t - SLA_HOURS, 0))
    C = np.array(cols).T
    cap = [26, 18, 16]
    A_eq = np.zeros((n, n * 3)); A_ub = np.zeros((3, n * 3))
    for i in range(n): A_eq[i, i * 3:i * 3 + 3] = 1
    for j in range(3): A_ub[j, j::3] = 1
    res = linprog(C.flatten(), A_ub=A_ub, b_ub=cap, A_eq=A_eq, b_eq=np.ones(n), bounds=(0, 1))
    naive, idx = 0, 0
    for j, c in enumerate(cap):
        naive += C[idx:idx + c, j].sum(); idx += c
    print(f"Naive cost {naive:.0f} | optimized {res.fun:.0f} | saving {(naive - res.fun) / naive * 100:.1f}%")


def what_if_rush(model, X_test):
    Xw = X_test.copy()
    rush = Xw.is_rush_hour == 1
    Xw.loc[rush, "is_rush_hour"] = 0
    saving = model.predict(X_test) - model.predict(Xw)
    print(f"Avg time saved moving rush-hour shipments off-peak: {saving[rush.values].mean():.2f} hr")


def main():
    X, y = prepare(simulate_data())
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=SEED)
    kf = KFold(5, shuffle=True, random_state=SEED)
    compare_models(X_train, y_train, X_test, y_test, kf)
    best = tune(X_train, y_train, kf)
    pred = best.predict(X_test)
    print(f"TUNED: RMSE {mean_squared_error(y_test, pred) ** .5:.3f} "
          f"MAE {mean_absolute_error(y_test, pred):.3f} R2 {r2_score(y_test, pred):.3f}")
    print(pd.Series(best.feature_importances_, index=X.columns).nlargest(8).round(3))
    sla_alert(y_test, pred)
    optimize_assignment(best, X_test.iloc[:60])
    what_if_rush(best, X_test)


if __name__ == "__main__":
    main()
